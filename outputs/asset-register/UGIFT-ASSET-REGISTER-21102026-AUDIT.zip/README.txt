UgIFT asset register audit evidence

manifest.json identifies the retained workbook and hashes every preserved audit file.
verification/hospital-restoration-work records the final 228,638-asset scope and workbook checks.
Other verification folders and history retain earlier evidence and may describe superseded scopes.
The cleanup renamed the final reconciled workbook without changing its contents.
